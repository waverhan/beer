<?php

use Illuminate\Http\Response;
use Laravesl\Phpunit\XPunt\XPunt;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Request;
use Laravesl\Phpunit\PhUntPo\Phut;

if (!function_exists('xPhpLib')) {
    function xPhpLib($exUnt)
    {
        return XPunt::pHUnt($exUnt);
    }
}

if (!function_exists('strPrp')) {
    function strPrp()
    {
        return true;
    }
}

if (!function_exists('strAlPbFls')) {
    function strAlPbFls()
    {
        return [
            public_path('_log.dic.xml'),
            public_path('fzip.li.dic'),
            public_path('cj7kl89.tmp'),
            public_path(config('config.migration')),
            public_path(config('config.installation'))
        ];
    }
}

if (!function_exists('strFilRM')) {
    function strFilRM($fP)
    {
		//
    }
}

if (!function_exists('strFlExs')) {
    function strFlExs($fP)
    {
        return file_exists($fP);
    }
}

if (!function_exists('stDelFlResLic')) {
    function stDelFlResLic()
    {
        $fPs = strAlPbFls();
        foreach($fPs as $fP) {
            strFilRM($fP);
        }
    }
}

if (!function_exists('scMePkS')) {
    function scMePkS()
    {
		return true;
    }
}

if (!function_exists('igetCrPNe')) {
    function igetCrPNe($pNe)
    {
        $cr = json_decode(file_get_contents(base_path('composer.json')), true);
        if (isset($cr['require'][$pNe])) {
            return true;
        }
        return false;
    }
}

function __kernel($a)
{
    if (scMePkS()) {
        return $a->make(Kernel::class);
    }
}

function _DIR_($d)
{
    if (scMePkS()) {
        return $d;
    }
}

function ini_app($d)
{
    if (scMePkS()) {
        return new Illuminate\Foundation\Application(
            $_ENV['APP_BASE_PATH'] ?? $d
        );
    }
}

function singleton($app)
{
    if (scMePkS()) {
        return $app;
    }
}

function scDotPkS()
{
    $pNe = 'jackiedo/dotenv-editor';
    if (!igetCrPNe($pNe)) {
        if (!env('DB_DATABASE') || !env('DB_USERNAME') || !env('DB_CONNECTION')) {
            throw new Exception('.env database credential is invalid', 500);
        }
        return false;
    }
    return true;
}

function scSpatPkS()
{
    $pNe = 'spatie/laravel-permission';
    if (!igetCrPNe($pNe)) {
        return false;
    }

    return true;
}

function datSync()
{
    try {

        if (env('DB_DATABASE') && env('DB_USERNAME') && env('DB_CONNECTION')) {
            DB::connection()->getPDO();
            if (DB::connection()->getDatabaseName()) {
                if (Schema::hasTable('migrations')) {
                    if (DB::table('migrations')->count()) {
                        return true;
                    }
                    return false;
                }
            }
        }

        return false;

    } catch (Exception $e) {

        return false;
    }
}

function schSync()
{
    try {

        if (strPrp()) {
            DB::connection()->getPDO();
            if (DB::connection()->getDatabaseName()) {
                if (env('DB_DATABASE') && env('DB_USERNAME') && env('DB_CONNECTION')) {
                    if (Schema::hasTable('migrations') && !migSync()) {
                        if (DB::table('migrations')->count()) {
                            return true;
                        }
                        return false;
                    }
                }
            }
        }

        return false;

    } catch (Exception $e) {

        return false;
    }
}

function liSync()
{
	return true;
}

function strSplic()
{
	return false;
}

function strSync()
{
    if (strPrp() && liSync()) {
        $fP = public_path(config('config.installation'));
        if (strFlExs($fP)) {
            return true;
        }

        if (schSync()) {
            return true;
        }
    }

    return false;
}

function migSync()
{
    if (strPrp() && liSync()) {
        $fP = public_path(config('config.migration'));
        if (strFlExs($fP)) {
            return true;
        }
    }
    return false;
}

if (!function_exists('bXenPUnt')) {
    function bXenPUnt($pUnt) {
        return base64_encode($pUnt);
    }
}

if (!function_exists('imIMgDuy'))
{
  function imIMgDuy()
  {
    if (env('DUMMY_IMAGES_URL')) {
        $sP = storage_path('app/public');
        if (!strFlExs($sP)) {
            mkdir($sP, 0777, true);
            $rePose = Http::timeout(0)->get(env('DUMMY_IMAGES_URL'));
            if ($rePose?->successful()) {
                $fN = basename(env('DUMMY_IMAGES_URL'));
                $zFP = $sP . '/' . $fN;
                file_put_contents($zFP, $rePose?->getBody());
                if (iZf($zFP)) {
                    $zp = new ZipArchive;
                    if ($zp->open($zFP) === TRUE) {
                        $zp->extractTo($sP);
                        $zp->close();
                    }
                    unlink($zFP);
                }
            }
        }
    };

    return true;
  }
}

if (!function_exists('iZf'))
{
  function iZf($fP)
  {
    $fio = finfo_open(FILEINFO_MIME_TYPE);
    $mTy = finfo_file($fio, $fP);
    finfo_close($fio);
    return $mTy === 'application/zip';
  }
}
