<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title') - Installation Wizard</title>
    <link rel="icon" href="{{ asset('favicon.png') }}" type="image/x-icon">
    <link rel="shortcut icon" href="{{ asset('favicon.png') }}" type="image/x-icon">

    <!--Google font-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('install/css/vendors/bootstrap.css') }}">
    <link rel="stylesheet" href="{{ asset('install/css/vendors/feathericon.min.css') }}">
    <link rel="stylesheet" href="{{ asset('install/css/vendors/animate.css') }}">
    <link rel="stylesheet" href="{{ asset('install/css/app.css') }}">
    @yield('style')
</head>

<body>
    <div class="page-wrapper">
        <div class="wizard-bg">
            <div class="container">
                <div class="wizard-box">
                    <div style="align-content: center;text-align: center;font-size: 20px;">
                        NULLLED by raz0r - <a style="color:red;" href="https://bit.ly/3Uz8hZ" target="_blank">Web Community</a>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="wizard-step-container">
                                <ul class="step-container">
                                    <li class="step-container step-1 @if (Route::is('install.requirements')) active @else disabled @endif">
                                        <div class="media">
                                            <div class="step-icon">
                                                <i class="fa fa-check"></i>
                                            </div>
                                            <span>1</span>
                                        </div>
                                        <div class="media-body">
                                            <h5>Requirements</h5>
                                            <h6>PHP Extensions</h6>
                                        </div>
                                        <div class="icon-center">
                                            <i data-feather="chevrons-right"></i>
                                        </div>
                                    </li>
                                    <li class="step-container step-2 @if (Route::is('install.directories')) active @elseif(Route::is('install.license') || Route::is('install.database') || Route::is('install.completed')) disabled @endif">
                                        <div class="media">
                                            <div class="step-icon">
                                                <i class="fa fa-check"></i>
                                            </div>
                                            <span>2</span>
                                        </div>
                                        <div class="media-body">
                                            <h5>Directories</h5>
                                            <h6>Permissions</h6>
                                        </div>
                                        <div class="icon-center">
                                            <i data-feather="chevrons-right"></i>
                                        </div>
                                    </li>
                                    <li class="step-container step-3 @if (Route::is('install.license')) active @elseif(Route::is('install.database') || Route::is('install.completed')) disabled @endif">
                                        <div class="media">
                                            <div class="step-icon">
                                                <i class="fa fa-check"></i>
                                            </div>
                                            <span>3</span>
                                        </div>
                                        <div class="media-body">
                                            <h5>License</h5>
                                            <h6>Purchase Code</h6>
                                        </div>
                                        <div class="icon-center">
                                            <i data-feather="chevrons-right"></i>
                                        </div>
                                    </li>
                                    <li class="step-container step-4 @if (Route::is('install.database')) active @elseif(Route::is('install.completed')) disabled @endif">
                                        <div class="media">
                                            <div class="step-icon">
                                                <i class="fa fa-check"></i>
                                            </div>
                                            <span>4</span>
                                        </div>
                                        <div class="media-body">
                                            <h5>Configuration</h5>
                                            <h6>Connection Details</h6>
                                        </div>
                                        <div class="icon-center">
                                            <i data-feather="chevrons-right"></i>
                                        </div>
                                    </li>
                                    <li class="step-container step-5 @if (Route::is('install.completed')) active @else '' @endif">
                                        <div class="media">
                                            <div class="step-icon">
                                                <i class="fa fa-check"></i>
                                            </div>
                                            <span>5</span>
                                        </div>
                                        <div class="media-body">
                                            <h5>Complete</h5>
                                            <h6>Installation Complete</h6>
                                        </div>
                                        <div class="icon-center">
                                            <i data-feather="chevrons-right"></i>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="wizard-form-details">
                                @include('stvs::sts')
                                @yield('content')
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJUV5yExlq6GSYGSBk7tPXikyS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="{{ asset('install/js/popper.min.js') }}"></script>
    <script src="{{ asset('install/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('install/js/feather.min.js') }}"></script>
    <script>
        feather.replace()
    </script>
</body>
</html>
