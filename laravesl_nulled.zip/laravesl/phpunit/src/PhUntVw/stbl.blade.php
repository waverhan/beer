@extends(xPhpLib('c3R2OjpzdG12'))
@section('title', xPhpLib('VmVyaWZ5'))
@section(xPhpLib('Y29udGVudA=='))
    <div>
        <form action="{{ route(xPhpLib('aW5zdGFsbC51bmJsb2Nr')) }}" method=@phXml('UE9TVA==')>
            @csrf
            @method(xPhpLib('UE9TVA=='))
           @phXml('IDxkaXYgY2xhc3M9InJvdyI+DQogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0iZGF0YWJhc2UtZmllbGQgY29sLW1kLTEyIj4NCiAgICAgICAgICAgICAgICAgICAgPGg2PllvdXIgQ3VycmVudCBsaWNlbnNlIGlzIEJsb2NrZWQuIFBsZWFzZSBlbnRlciBuZXcgbGljZW5zZSBkZXRhaWxzIGJlbG93IGZvciBhY3RpdmUgbGljZW5zZS48L2g2Pg0KDQogICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9ImZvcm0tZ3JvdXAgZm9ybS1yb3ciPg0KICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkVudmF0byBVc2VybmFtZTxzcGFuIGNsYXNzPSJyZXF1aXJlZC1maWxsIj4qPC9zcGFuPjwvbGFiZWw+DQogICAgICAgICAgICAgICAgICAgICAgICA8ZGl2Pg==')
                           @phXml('IDxpbnB1dCB0eXBlPSJ0ZXh0IiBuYW1lPSJlbnZhdG9fdXNlcm5hbWUi') value="{{ old(xPhpLib('ZW52YXRvX3VzZXJuYW1l')) }}"
                                @phXml('Y2xhc3M9ImZvcm0tY29udHJvbCIgYXV0b2NvbXBsZXRlPSJvZmYiPg==')
                            @if ($errors->has(xPhpLib('ZW52YXRvX3VzZXJuYW1l')))
                                @phXml('PHNwYW4gY2xhc3M9InRleHQtZGFuZ2VyIj4='){{ $errors->first(xPhpLib('ZW52YXRvX3VzZXJuYW1l')) }}@phXml('PC9zcGFuPg==')
                            @endif
                        @phXml('PC9kaXY+DQogICAgICAgICAgICAgICAgICAgIDwvZGl2Pg0KDQogICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9ImZvcm0tZ3JvdXAgZm9ybS1yb3ciPg0KICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPkxpY2Vuc2UgQ29kZTxzcGFuIGNsYXNzPSJyZXF1aXJlZC1maWxsIj4qPC9zcGFuPjwvbGFiZWw+DQogICAgICAgICAgICAgICAgICAgICAgICA8ZGl2Pg==')
                           @phXml('IDxpbnB1dCB0eXBlPSJ0ZXh0IiBuYW1lPSJsaWNlbnNlIiA=') value="{{ old(xPhpLib('bGljZW5zZQ==')) }}"
                                @phXml('Y2xhc3M9ImZvcm0tY29udHJvbCIgYXV0b2NvbXBsZXRlPSJvZmYiPg==')
                            @if ($errors->has(xPhpLib('bGljZW5zZQ==')))
                                @phXml('PHNwYW4gY2xhc3M9InRleHQtZGFuZ2VyIj4='){{ $errors->first(xPhpLib('bGljZW5zZQ==')) }}@phXml('PC9zcGFuPg==')
                            @endif
                        @phXml('PC9kaXY+DQogICAgICAgICAgICAgICAgICAgIDwvZGl2Pg0KPGRpdj4NCklmIHlvdSBkb24ndCBrbm93IGhvdyB0byBnZXQgcHVyY2hhc2UgY29kZSwgY2xpY2sgaGVyZTogPGEgaHJlZiA9Imh0dHBzOi8vaGVscC5tYXJrZXQuZW52YXRvLmNvbS9oYy9lbi11cy9hcnRpY2xlcy8yMDI4MjI2MDAtV2hlcmUtSXMtTXktUHVyY2hhc2UtQ29kZSI+IHdoZXJlIGlzIG15IHB1cmNoYXNlIGNvZGUgPC9hPg0KPC9kaXY+DQogICAgICAgICAgICAgICAgPC9kaXY+DQogICAgICAgICAgICA8L2Rpdj4NCiAgICAgICAgPC9mb3JtPg0KICAgICAgICA8ZGl2IGNsYXNzPSJuZXh0LWJ0biBkLWZsZXgiPg0KICAgICAgICAgICAgPGEgaHJlZj0iamF2YXNjcmlwdDp2b2lkKDApIiBjbGFzcz0iYnRuIGJ0bi1wcmltYXJ5IHN1bWl0LWZvcm0iPkFjdGl2ZSA8aQ0KICAgICAgICAgICAgICAgICAgICBjbGFzcz0iZmFyIGZhLWhhbmQtcG9pbnQtcmlnaHQgbXMtMiI+PC9pPjwvYT4NCiAgICAgICAgPC9kaXY+DQogICAgPC9kaXY+')
@endsection
@section(xPhpLib('c2NyaXB0cw=='))
    @phXml('PHNjcmlwdD4NCiAgICAgICAgJCgiLnN1bWl0LWZvcm0iKS5jbGljayhmdW5jdGlvbigpIHsNCiAgICAgICAgICAgICQoImZvcm0iKS5zdWJtaXQoKTsNCiAgICAgICAgfSk7DQogICAgPC9zY3JpcHQ+')
@endsection
