<?php

namespace Laravesl\Phpunit\PhUntPo;

use Exception;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Http;

class Phut
{
    public function retLe()
    {
    }

    public function vl($r)
    {
    }

    public function lg($cnDTyP, $trGLi)
    {
    }
}
