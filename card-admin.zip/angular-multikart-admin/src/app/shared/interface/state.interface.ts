export interface States {
    id: number;
    name: string;
    country_id: number;
}