export const sort = [
    {
      value: 'asc',
      label: 'asc',
    },
    {
      value: 'desc',
      label: 'desc',
    },
]

export const product_list_type = [
    {
        value: 'top-selling',
        label: 'Top selling',
    },
    {
        value: 'recent',
        label: 'Recent',
    },
    {
        value: 'trending',
        label: 'Trending',
    },
    {
        value: 'specific-product',
        label: 'Specific-product',
    },
    {
        value: 'random',
        label: 'Random',
    },
]