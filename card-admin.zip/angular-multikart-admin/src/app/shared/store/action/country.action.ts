export class GetCountries {
  static readonly type = "[Country] Get";
  constructor() {}
}