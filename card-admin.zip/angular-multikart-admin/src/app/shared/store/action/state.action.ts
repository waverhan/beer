export class GetStates {
  static readonly type = "[State] Get";
  constructor(public country_id?: number) {}
}