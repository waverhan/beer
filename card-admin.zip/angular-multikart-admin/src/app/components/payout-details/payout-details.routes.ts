import { Routes } from "@angular/router";
import { PayoutDetailsComponent } from "./payout-details.component";

export const payoutDetailsRoutes: Routes = [
  {
    path: '',
    component: PayoutDetailsComponent
  }
];
