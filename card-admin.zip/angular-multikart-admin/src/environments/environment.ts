export const environment = {
  production: false,
  URL: 'https://api.your.domain.com/api/admin', // Change only the domain part, keeping "/api/admin" intact
  storageURL: 'https://api.your.domain.com', // Change only the laravel primary domain
};