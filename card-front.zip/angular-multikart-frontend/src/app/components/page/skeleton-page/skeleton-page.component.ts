import { Component } from '@angular/core';

@Component({
  selector: 'app-skeleton-page',
  standalone: true,
  imports: [],
  templateUrl: './skeleton-page.component.html',
  styleUrl: './skeleton-page.component.scss'
})
export class SkeletonPageComponent {

}
