<?php

namespace App\Enums;

enum ReactionEnum:string {
  const LIKED = 'liked';
  const DISLIKED = 'disliked';
}
