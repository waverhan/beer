<?php

namespace App\Enums;

enum TransactionType:string {
  const CREDIT = 'credit';
  const DEBIT = 'debit';
}
