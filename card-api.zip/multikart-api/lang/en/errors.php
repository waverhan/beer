<?php

return [
    "something_went_wrong" => "Something Went Wrong",
    "get_category" => env('APP_NAME'),
];
